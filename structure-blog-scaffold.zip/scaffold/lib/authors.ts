import fs from "node:fs";
import path from "node:path";

export type Author = {
  slug: string;
  name: string;
  title: string;
  bio: string;
  photo: string;
  links: {
    linkedin?: string;
    twitter?: string;
    website?: string;
  };
};

const AUTHORS_DIR = path.join(process.cwd(), "content", "authors");

export function getAuthor(slug: string): Author | null {
  const filePath = path.join(AUTHORS_DIR, `${slug}.json`);
  if (!fs.existsSync(filePath)) return null;
  return JSON.parse(fs.readFileSync(filePath, "utf-8")) as Author;
}

export function getAllAuthors(): Author[] {
  if (!fs.existsSync(AUTHORS_DIR)) return [];
  return fs
    .readdirSync(AUTHORS_DIR)
    .filter((f) => f.endsWith(".json"))
    .map((f) => getAuthor(f.replace(/\.json$/, "")))
    .filter((a): a is Author => a !== null);
}
