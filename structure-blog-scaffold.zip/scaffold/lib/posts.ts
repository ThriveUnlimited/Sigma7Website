import fs from "node:fs";
import path from "node:path";
import matter from "gray-matter";
import readingTime from "reading-time";
import type { CategorySlug } from "./site";

export type PostFrontmatter = {
  title: string;
  slug: string;
  description: string;
  publishedAt: string; // ISO date, e.g. "2026-05-15"
  updatedAt: string;
  author: string; // matches a file in content/authors/
  category: CategorySlug;
  tags: string[];
  featuredImage?: string;
  ogImage?: string;
  draft?: boolean;
};

export type Post = {
  frontmatter: PostFrontmatter;
  content: string;
  readingTime: string;
};

const POSTS_DIR = path.join(process.cwd(), "content", "posts");

/**
 * List slugs of all posts on disk (including drafts).
 * Use for generateStaticParams.
 */
export function getAllPostSlugs(): string[] {
  if (!fs.existsSync(POSTS_DIR)) return [];
  return fs
    .readdirSync(POSTS_DIR)
    .filter((f) => f.endsWith(".mdx"))
    .map((f) => f.replace(/\.mdx$/, ""));
}

/**
 * Load a single post by slug.
 * Returns null if file is missing or marked draft in production.
 */
export function getPostBySlug(slug: string): Post | null {
  const filePath = path.join(POSTS_DIR, `${slug}.mdx`);
  if (!fs.existsSync(filePath)) return null;

  const raw = fs.readFileSync(filePath, "utf-8");
  const { data, content } = matter(raw);
  const frontmatter = { slug, ...data } as PostFrontmatter;

  // In production, hide draft posts entirely.
  if (frontmatter.draft && process.env.NODE_ENV === "production") {
    return null;
  }

  return {
    frontmatter,
    content,
    readingTime: readingTime(content).text,
  };
}

/**
 * All published posts, sorted newest first.
 */
export function getAllPosts(): Post[] {
  return getAllPostSlugs()
    .map((slug) => getPostBySlug(slug))
    .filter((p): p is Post => p !== null)
    .sort(
      (a, b) =>
        new Date(b.frontmatter.publishedAt).getTime() -
        new Date(a.frontmatter.publishedAt).getTime(),
    );
}

export function getPostsByCategory(category: string): Post[] {
  return getAllPosts().filter((p) => p.frontmatter.category === category);
}

export function getPostsByAuthor(authorSlug: string): Post[] {
  return getAllPosts().filter((p) => p.frontmatter.author === authorSlug);
}

export function getAllCategories(): string[] {
  return Array.from(new Set(getAllPosts().map((p) => p.frontmatter.category)));
}

export function getAllAuthorSlugs(): string[] {
  return Array.from(new Set(getAllPosts().map((p) => p.frontmatter.author)));
}
