/**
 * Centralized site config. Import from here everywhere so you only
 * have one place to change a URL, brand string, or social handle.
 */
export const siteConfig = {
  name: "Structure",
  url: "https://www.usestructure.com",
  description:
    "The all-in-one platform to manage your properties, projects, and guests.",
  twitter: "@usestructure", // TODO: replace with your real handle
  ogImageDefault: "/img/og-default.png", // 1200x630 fallback OG image
  logo: "/img/structure-logo.png",
} as const;

/**
 * Blog categories — one per major audience.
 * The keys become URL slugs at /blog/category/{key}.
 * Update labels and descriptions; they appear on category pages
 * and feed into title tags and meta descriptions.
 */
export const BLOG_CATEGORIES = {
  homeowners: {
    label: "Homeowners",
    description:
      "Guides, checklists, and tools for keeping up with the home you own.",
  },
  landlords: {
    label: "Landlords",
    description:
      "Managing rentals: tenants, repairs, expenses, and the paperwork in between.",
  },
  hosting: {
    label: "Hosting",
    description:
      "Running short-term rentals — guest communication, turnovers, and operations.",
  },
  "property-managers": {
    label: "Property Managers",
    description:
      "Tools and playbooks for managing portfolios on behalf of owners.",
  },
} as const;

export type CategorySlug = keyof typeof BLOG_CATEGORIES;
