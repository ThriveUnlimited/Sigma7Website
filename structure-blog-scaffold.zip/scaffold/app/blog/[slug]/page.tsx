import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import type { Metadata } from "next";
import { MDXRemote } from "next-mdx-remote/rsc";
import remarkGfm from "remark-gfm";
import rehypeSlug from "rehype-slug";
import rehypeAutolinkHeadings from "rehype-autolink-headings";

import { getAllPostSlugs, getPostBySlug } from "@/lib/posts";
import { getAuthor } from "@/lib/authors";
import { siteConfig, BLOG_CATEGORIES } from "@/lib/site";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return getAllPostSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) return {};

  const { frontmatter } = post;
  const url = `${siteConfig.url}/blog/${slug}`;
  const ogImage = frontmatter.ogImage
    ? `${siteConfig.url}${frontmatter.ogImage}`
    : `${siteConfig.url}${siteConfig.ogImageDefault}`;

  return {
    title: frontmatter.title,
    description: frontmatter.description,
    alternates: { canonical: url },
    openGraph: {
      type: "article",
      url,
      title: frontmatter.title,
      description: frontmatter.description,
      publishedTime: frontmatter.publishedAt,
      modifiedTime: frontmatter.updatedAt,
      images: [{ url: ogImage, width: 1200, height: 630 }],
      siteName: siteConfig.name,
    },
    twitter: {
      card: "summary_large_image",
      title: frontmatter.title,
      description: frontmatter.description,
      images: [ogImage],
      site: siteConfig.twitter,
    },
  };
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export default async function PostPage({ params }: Props) {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) notFound();

  const { frontmatter, content, readingTime: rt } = post;
  const author = getAuthor(frontmatter.author);
  const category = BLOG_CATEGORIES[frontmatter.category];
  const url = `${siteConfig.url}/blog/${slug}`;

  // Article JSON-LD — eligible for richer Google snippets.
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: frontmatter.title,
    description: frontmatter.description,
    image: frontmatter.featuredImage
      ? `${siteConfig.url}${frontmatter.featuredImage}`
      : `${siteConfig.url}${siteConfig.ogImageDefault}`,
    datePublished: frontmatter.publishedAt,
    dateModified: frontmatter.updatedAt,
    author: author
      ? {
          "@type": "Person",
          name: author.name,
          url: `${siteConfig.url}/blog/author/${author.slug}`,
        }
      : { "@type": "Organization", name: siteConfig.name },
    publisher: {
      "@type": "Organization",
      name: siteConfig.name,
      logo: {
        "@type": "ImageObject",
        url: `${siteConfig.url}${siteConfig.logo}`,
      },
    },
    mainEntityOfPage: { "@type": "WebPage", "@id": url },
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Blog",
        item: `${siteConfig.url}/blog`,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: category?.label ?? frontmatter.category,
        item: `${siteConfig.url}/blog/category/${frontmatter.category}`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: frontmatter.title,
        item: url,
      },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />

      <article className="mx-auto max-w-3xl px-6 py-12">
        <nav aria-label="Breadcrumb" className="mb-6 text-sm text-gray-500">
          <Link href="/blog" className="hover:underline">
            Blog
          </Link>
          <span className="mx-2">/</span>
          <Link
            href={`/blog/category/${frontmatter.category}`}
            className="hover:underline"
          >
            {category?.label ?? frontmatter.category}
          </Link>
        </nav>

        <header className="mb-8">
          <h1 className="mb-4 text-4xl font-bold tracking-tight">
            {frontmatter.title}
          </h1>
          <p className="text-lg text-gray-600">{frontmatter.description}</p>

          <div className="mt-6 flex flex-wrap items-center gap-4 text-sm text-gray-500">
            {author && (
              <Link
                href={`/blog/author/${author.slug}`}
                className="flex items-center gap-2 hover:underline"
              >
                {author.photo && (
                  <Image
                    src={author.photo}
                    alt={author.name}
                    width={32}
                    height={32}
                    className="h-8 w-8 rounded-full"
                  />
                )}
                <span>{author.name}</span>
              </Link>
            )}
            <time dateTime={frontmatter.publishedAt}>
              {formatDate(frontmatter.publishedAt)}
            </time>
            <span>{rt}</span>
          </div>

          {frontmatter.updatedAt &&
            frontmatter.updatedAt !== frontmatter.publishedAt && (
              <div className="mt-2 text-sm text-gray-500">
                Updated{" "}
                <time dateTime={frontmatter.updatedAt}>
                  {formatDate(frontmatter.updatedAt)}
                </time>
              </div>
            )}
        </header>

        {frontmatter.featuredImage && (
          <div className="mb-8 overflow-hidden rounded-lg">
            <Image
              src={frontmatter.featuredImage}
              alt={frontmatter.title}
              width={1200}
              height={630}
              priority
              className="h-auto w-full"
            />
          </div>
        )}

        <div className="prose prose-lg max-w-none">
          <MDXRemote
            source={content}
            options={{
              mdxOptions: {
                remarkPlugins: [remarkGfm],
                rehypePlugins: [
                  rehypeSlug,
                  [
                    rehypeAutolinkHeadings,
                    { behavior: "wrap", properties: { className: ["anchor"] } },
                  ],
                ],
              },
            }}
          />
        </div>

        {/* TODO: Add <PostCTA category={frontmatter.category} /> here.
            Drop in a contextual CTA linking to the matching segment page
            (homeowners → /homeowners, etc.). Big driver of blog → signup. */}
      </article>
    </>
  );
}
