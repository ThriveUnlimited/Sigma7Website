import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { getPostsByCategory } from "@/lib/posts";
import { BLOG_CATEGORIES, siteConfig, type CategorySlug } from "@/lib/site";

type Props = { params: Promise<{ category: string }> };

export async function generateStaticParams() {
  return Object.keys(BLOG_CATEGORIES).map((category) => ({ category }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { category } = await params;
  const cat = BLOG_CATEGORIES[category as CategorySlug];
  if (!cat) return {};
  const url = `${siteConfig.url}/blog/category/${category}`;
  return {
    title: `${cat.label} — Structure Blog`,
    description: cat.description,
    alternates: { canonical: url },
    openGraph: {
      type: "website",
      url,
      title: `${cat.label} — Structure Blog`,
      description: cat.description,
      siteName: siteConfig.name,
    },
  };
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export default async function CategoryPage({ params }: Props) {
  const { category } = await params;
  const cat = BLOG_CATEGORIES[category as CategorySlug];
  if (!cat) notFound();

  const posts = getPostsByCategory(category);

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      <nav aria-label="Breadcrumb" className="mb-6 text-sm text-gray-500">
        <Link href="/blog" className="hover:underline">
          Blog
        </Link>
        <span className="mx-2">/</span>
        <span>{cat.label}</span>
      </nav>

      <header className="mb-12">
        <h1 className="mb-3 text-4xl font-bold tracking-tight">{cat.label}</h1>
        <p className="text-lg text-gray-600">{cat.description}</p>
      </header>

      {posts.length === 0 ? (
        <p className="text-gray-500">
          No posts in this category yet — check back soon.
        </p>
      ) : (
        <div className="space-y-10">
          {posts.map((post) => (
            <article
              key={post.frontmatter.slug}
              className="border-b border-gray-200 pb-10"
            >
              <h2 className="mb-2 text-2xl font-semibold tracking-tight">
                <Link
                  href={`/blog/${post.frontmatter.slug}`}
                  className="hover:underline"
                >
                  {post.frontmatter.title}
                </Link>
              </h2>
              <p className="text-gray-600">{post.frontmatter.description}</p>
              <div className="mt-3 text-sm text-gray-500">
                <time dateTime={post.frontmatter.publishedAt}>
                  {formatDate(post.frontmatter.publishedAt)}
                </time>
                <span className="mx-2">·</span>
                {post.readingTime}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
