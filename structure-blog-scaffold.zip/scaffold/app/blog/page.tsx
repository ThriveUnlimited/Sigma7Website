import type { Metadata } from "next";
import Link from "next/link";
import { getAllPosts } from "@/lib/posts";
import { siteConfig, BLOG_CATEGORIES } from "@/lib/site";

export const metadata: Metadata = {
  title: "Blog — Structure",
  description:
    "Guides, checklists, and insights for property owners, landlords, hosts, and managers.",
  alternates: { canonical: `${siteConfig.url}/blog` },
  openGraph: {
    type: "website",
    url: `${siteConfig.url}/blog`,
    title: "Structure Blog",
    description:
      "Guides, checklists, and insights for property owners, landlords, hosts, and managers.",
    siteName: siteConfig.name,
  },
};

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export default function BlogIndex() {
  const posts = getAllPosts();

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      <header className="mb-12">
        <h1 className="mb-4 text-4xl font-bold tracking-tight">Blog</h1>
        <p className="text-lg text-gray-600">
          Guides, checklists, and insights for property owners, landlords,
          hosts, and managers.
        </p>

        <nav className="mt-6 flex flex-wrap gap-2" aria-label="Categories">
          {Object.entries(BLOG_CATEGORIES).map(([slug, cat]) => (
            <Link
              key={slug}
              href={`/blog/category/${slug}`}
              className="rounded-full border border-gray-200 px-4 py-1.5 text-sm hover:bg-gray-50"
            >
              {cat.label}
            </Link>
          ))}
        </nav>
      </header>

      {posts.length === 0 ? (
        <p className="text-gray-500">No posts yet — check back soon.</p>
      ) : (
        <div className="space-y-10">
          {posts.map((post) => (
            <article
              key={post.frontmatter.slug}
              className="border-b border-gray-200 pb-10"
            >
              <div className="mb-2 text-xs uppercase tracking-wide text-gray-500">
                {BLOG_CATEGORIES[post.frontmatter.category]?.label ??
                  post.frontmatter.category}
              </div>
              <h2 className="mb-2 text-2xl font-semibold tracking-tight">
                <Link
                  href={`/blog/${post.frontmatter.slug}`}
                  className="hover:underline"
                >
                  {post.frontmatter.title}
                </Link>
              </h2>
              <p className="text-gray-600">{post.frontmatter.description}</p>
              <div className="mt-3 text-sm text-gray-500">
                <time dateTime={post.frontmatter.publishedAt}>
                  {formatDate(post.frontmatter.publishedAt)}
                </time>
                <span className="mx-2">·</span>
                {post.readingTime}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
