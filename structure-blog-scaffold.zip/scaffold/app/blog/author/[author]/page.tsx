import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import type { Metadata } from "next";
import { getAuthor, getAllAuthors } from "@/lib/authors";
import { getPostsByAuthor } from "@/lib/posts";
import { siteConfig } from "@/lib/site";

type Props = { params: Promise<{ author: string }> };

export async function generateStaticParams() {
  return getAllAuthors().map((a) => ({ author: a.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { author: slug } = await params;
  const author = getAuthor(slug);
  if (!author) return {};
  const url = `${siteConfig.url}/blog/author/${slug}`;
  return {
    title: `${author.name} — Structure Blog`,
    description: author.bio,
    alternates: { canonical: url },
    openGraph: {
      type: "profile",
      url,
      title: author.name,
      description: author.bio,
      siteName: siteConfig.name,
    },
  };
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export default async function AuthorPage({ params }: Props) {
  const { author: slug } = await params;
  const author = getAuthor(slug);
  if (!author) notFound();

  const posts = getPostsByAuthor(slug);

  // Person JSON-LD — E-E-A-T signal that Google increasingly weighs.
  const personSchema = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: author.name,
    jobTitle: author.title,
    description: author.bio,
    image: author.photo ? `${siteConfig.url}${author.photo}` : undefined,
    url: `${siteConfig.url}/blog/author/${author.slug}`,
    sameAs: [
      author.links.linkedin,
      author.links.twitter
        ? `https://twitter.com/${author.links.twitter.replace("@", "")}`
        : undefined,
      author.links.website,
    ].filter(Boolean),
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(personSchema) }}
      />

      <div className="mx-auto max-w-3xl px-6 py-12">
        <nav aria-label="Breadcrumb" className="mb-6 text-sm text-gray-500">
          <Link href="/blog" className="hover:underline">
            Blog
          </Link>
          <span className="mx-2">/</span>
          <span>{author.name}</span>
        </nav>

        <header className="mb-12 flex items-start gap-6">
          {author.photo && (
            <Image
              src={author.photo}
              alt={author.name}
              width={96}
              height={96}
              className="h-24 w-24 rounded-full"
            />
          )}
          <div>
            <h1 className="mb-1 text-3xl font-bold tracking-tight">
              {author.name}
            </h1>
            <p className="mb-3 text-gray-500">{author.title}</p>
            <p className="text-gray-700">{author.bio}</p>
          </div>
        </header>

        <section>
          <h2 className="mb-6 text-xl font-semibold">
            Posts by {author.name}
          </h2>
          {posts.length === 0 ? (
            <p className="text-gray-500">No posts yet.</p>
          ) : (
            <div className="space-y-8">
              {posts.map((post) => (
                <article
                  key={post.frontmatter.slug}
                  className="border-b border-gray-200 pb-8"
                >
                  <h3 className="mb-2 text-xl font-semibold">
                    <Link
                      href={`/blog/${post.frontmatter.slug}`}
                      className="hover:underline"
                    >
                      {post.frontmatter.title}
                    </Link>
                  </h3>
                  <p className="text-gray-600">
                    {post.frontmatter.description}
                  </p>
                  <div className="mt-2 text-sm text-gray-500">
                    <time dateTime={post.frontmatter.publishedAt}>
                      {formatDate(post.frontmatter.publishedAt)}
                    </time>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </>
  );
}
