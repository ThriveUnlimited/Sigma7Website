import type { MetadataRoute } from "next";
import { getAllPosts } from "@/lib/posts";
import { BLOG_CATEGORIES, siteConfig } from "@/lib/site";
import { getAllAuthors } from "@/lib/authors";

/**
 * Generates /sitemap.xml. Next.js will serve this automatically.
 *
 * Add new static routes to STATIC_ROUTES below. Blog content is picked
 * up automatically from MDX files.
 */
const STATIC_ROUTES: Array<{ path: string; priority: number }> = [
  { path: "", priority: 1.0 },
  { path: "/homeowners", priority: 0.9 },
  { path: "/landlords", priority: 0.9 },
  { path: "/hosting", priority: 0.9 },
  { path: "/property-managers", priority: 0.9 },
  { path: "/blog", priority: 0.8 },
];

export default function sitemap(): MetadataRoute.Sitemap {
  const base = siteConfig.url;
  const now = new Date();

  const staticEntries = STATIC_ROUTES.map(({ path, priority }) => ({
    url: `${base}${path}`,
    lastModified: now,
    changeFrequency: "weekly" as const,
    priority,
  }));

  const postEntries = getAllPosts().map((post) => ({
    url: `${base}/blog/${post.frontmatter.slug}`,
    lastModified: new Date(post.frontmatter.updatedAt),
    changeFrequency: "monthly" as const,
    priority: 0.7,
  }));

  const categoryEntries = Object.keys(BLOG_CATEGORIES).map((slug) => ({
    url: `${base}/blog/category/${slug}`,
    lastModified: now,
    changeFrequency: "weekly" as const,
    priority: 0.6,
  }));

  const authorEntries = getAllAuthors().map((author) => ({
    url: `${base}/blog/author/${author.slug}`,
    lastModified: now,
    changeFrequency: "monthly" as const,
    priority: 0.4,
  }));

  return [
    ...staticEntries,
    ...postEntries,
    ...categoryEntries,
    ...authorEntries,
  ];
}
